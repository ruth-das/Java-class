package com.calc.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.calc.Calculator;
	
	public class CalculatorTest{
		static Calculator obj;

	
	@BeforeClass
	public static void beforeTest() {
		obj=new Calculator();
	}

	@Test
	public void testAdd() {
		//Calculator obj = new Calculator();
		int n = obj.add(10, 20);
		assertEquals(30, n);
	}

	@Test
	public void testSub() {
		//Calculator obj = new Calculator();
		int n = obj.sub(10, 5);
		assertEquals("Subtracting 10 & 5",5, n);
	}
	
	@Test
	public void testDivide() {
		//Calculator obj = new Calculator();
		int n = obj.divide(10, 2);
		assertEquals(5, n);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testDivideException(){
		//Calculator obj = new Calculator();
		int n=obj.divide(20,0);
	}
}