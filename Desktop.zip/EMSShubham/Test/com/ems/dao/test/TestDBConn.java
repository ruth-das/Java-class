package com.ems.dao.test;

import java.sql.Connection;

import org.junit.Ignore;
import org.junit.Test;

import static org.junit.Assert.*;

import com.emp.exception.EmployeeException;
import com.emp.util.DBConnection;


public class TestDBConn {
	
	@Test
	public void TestConnection()throws EmployeeException{
		Connection con=DBConnection.getConnection();
		assertNotNull(con);
	}
	
	//Is testcase ko successful dikhana ho to resources me jaake usrname ya pwd ko change karke dekho
	@Test(expected=EmployeeException.class)
	public void TestConnectionFail()throws EmployeeException{
		Connection con=DBConnection.getConnection();
	}
	

}
