package com.emp.util;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.emp.exception.EmployeeException;

public class DBConnection {
	

	public static Connection getConnection() throws EmployeeException
	{
		Connection con=null;
		Properties props=new Properties();
		
		try {
			FileReader fRead=new FileReader("resource/jdbc.properties");
			props.load(fRead);
			String url=props.getProperty("jdbcurl");
			String user=props.getProperty("jdbcuser");
			String pass=props.getProperty("jdbcpass");
			con=DriverManager.getConnection(url, user, pass);
		} catch (FileNotFoundException e) {
			throw new EmployeeException("jdbc.properties File not Found");
			
		} catch (IOException e) {
			throw new EmployeeException("Unable to read jdbc.properties file");
			
		} catch (SQLException e) {
			throw new EmployeeException("Connection failed");
			
		}
		return(con);
	}

}
