package com.emp.service;

import java.util.List;

import com.emp.bean.EmployeeBean;
import com.emp.dao.EmployeeDAO;
import com.emp.dao.EmployeeDAOImplement;
import com.emp.exception.EmployeeException;

public class EmployeeServiceImplementation implements EmployeeService{

	private EmployeeDAO employeedao=new EmployeeDAOImplement(); 
	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		int id=employeedao.addEmployee(bean);
		return id;
	}
	
	
	public void delEmployee(int id) throws EmployeeException{
		employeedao.delEmployee(id);
	}
	
	public String viewById(int id) throws EmployeeException{
		String bean=employeedao.viewById(id);
		return bean;
	}
	
	public List<EmployeeBean> viewAllEmployees(EmployeeBean bean) throws EmployeeException{
		List<EmployeeBean> emp=employeedao.viewAllEmployees(bean);
		return emp;
	}
	

}
